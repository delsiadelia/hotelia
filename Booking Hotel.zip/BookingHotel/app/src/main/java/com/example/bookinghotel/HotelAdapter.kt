package com.example.bookinghotel

// HotelAdapter.kt
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView

class HotelAdapter(private val hotelList: List<Hotel>) : RecyclerView.Adapter<HotelAdapter.HotelViewHolder>() {

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): HotelViewHolder {
        val view = LayoutInflater.from(parent.context).inflate(R.layout.item_hotel, parent, false)
        return HotelViewHolder(view)
    }

    override fun onBindViewHolder(holder: HotelViewHolder, position: Int) {
        val hotel = hotelList[position]
        holder.tvHotelName.text = hotel.name
        holder.tvHotelLocation.text = hotel.location
        holder.ivHotelImage.setImageResource(hotel.imageResId)
    }

    override fun getItemCount(): Int = hotelList.size

    inner class HotelViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView) {
        val tvHotelName: TextView = itemView.findViewById(R.id.tvHotelName)
        val tvHotelLocation: TextView = itemView.findViewById(R.id.tvHotelLocation)
        val ivHotelImage: ImageView = itemView.findViewById(R.id.ivHotelImage)
    }
}
