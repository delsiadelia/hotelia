package com.example.bookinghotel

import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.LinearLayoutManager
import com.example.bookinghotel.databinding.ActivityMainBinding

class MainActivity : AppCompatActivity() {
    private lateinit var binding: ActivityMainBinding
    private val hotelList = listOf(
        Hotel("Hotel Santika Premiere", "Jl. Ahmad Yani No. 20, 25112 Padang, Indonesia", R.drawable.h1),
        Hotel("Hotel Truntum", "Jl. Gereja No. 34, 25118 Padang, Indonesia", R.drawable.h2),
        Hotel("Hotel HW", "Jl.Hayam Wuruk No 16 Padang, West Sumatera – Indonesia", R.drawable.h3),
        Hotel("Hotel Whiz Prime ", "JL.Khatib Sulaiman No.48 A, Ulak Karang Sel., Kec. Padang Utara, Kota Padang, Sumatera Barat 25173 ", R.drawable.h4),
        Hotel("Hotel Grand Basko ", "Jl.Prof. Dr. Hamka No.2a, Air Tawar Bar., Kec. Padang Utara, Kota Padang, Sumatera Barat 25132 ", R.drawable.h5),
        Hotel("Hotel The ZHM Premire ", "Jl.Jl. Moh. Thamrin No.27, Alang Laweh, Kec. Padang Sel., Kota Padang, Sumatera Barat 25133 ", R.drawable.h6),
        Hotel("Hotel UNP ", "Jl.JL Nusa Indah No.21, RT.04/RW.02, Air Tawar Bar., Kec. Padang Utara, Kota Padang, Sumatera Barat 25173 ", R.drawable.h7)

    )

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        // Inisialisasi binding
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)

        binding.rvHotelList.layoutManager = LinearLayoutManager(this)
        binding.rvHotelList.adapter = HotelAdapter(hotelList)
    }
}
