package com.example.bookinghotel

// Hotel.kt
data class Hotel(
    val name: String,
    val location: String,
    val imageResId: Int
)
