package com.example.bookinghotel

// LoginActivity.kt
import android.content.Intent
import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import com.google.firebase.auth.FirebaseAuth

class LoginActivity : AppCompatActivity() {
    private lateinit var auth: FirebaseAuth

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_login)

        // Inisialisasi Firebase Auth
        auth = FirebaseAuth.getInstance()

        val etUsername = findViewById<EditText>(R.id.etUsername)
        val etPassword = findViewById<EditText>(R.id.etPassword)
        val btnLogin = findViewById<Button>(R.id.btnLogin)

        btnLogin.setOnClickListener {
            val username = etUsername.text.toString()
            val password = etPassword.text.toString()

            // Pengecekan username dan password untuk login admin
            if (username == "admin" && password == "admin") {
                startActivity(Intent(this, MainActivity::class.java))
                finish()
            } else {
                // Jika username dan password salah, lakukan login anonim
                signInAnonymously()
            }
        }
    }

    private fun signInAnonymously() {
        auth.signInAnonymously()
            .addOnCompleteListener(this) { task ->
                if (task.isSuccessful) {
                    // Login anonim berhasil
                    val user = auth.currentUser
                    Toast.makeText(this, "Login anonim berhasil: ${user?.uid}", Toast.LENGTH_SHORT).show()
                    startActivity(Intent(this, MainActivity::class.java))
                    finish()
                } else {
                    // Jika login anonim gagal, tampilkan pesan kesalahan
                    Toast.makeText(this, "Login anonim gagal: ${task.exception?.message}", Toast.LENGTH_SHORT).show()
                }
            }
    }
}